const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const assert = require("node:assert/strict");
(async () => {
  const browser = await chromium.launch({
    headless: true,
    ...(process.env.CHROME_PATH
      ? { executablePath: process.env.CHROME_PATH }
      : {}),
  });
  try {
    const page = await browser.newPage({
      viewport: { width: 1440, height: 1000 },
    });
    page.setDefaultTimeout(8000);
    const errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto(
      (process.env.ISSUEFLOW_URL || "http://127.0.0.1:8080") + "/changes.html",
    );
    const id = await page.evaluate(() => {
      const c = changes.find((c) => c.status === "Aprovada");
      c.status = "Em aprovação";
      c.cenarios = [];
      delete c.encerramento;
      delete c.pipeline;
      c.checklist = seedChecklistAnswers("full");
      persist();
      openQuickAction(c, "aprovar");
      return c.id;
    });
    await page.locator("#quickActionBody input").first().fill("Gerente");
    assert.equal(
      await page.locator("#quickActionBody .primary").isDisabled(),
      true,
    );
    assert.match(
      await page.textContent("#quickActionBody"),
      /Testes de PROD pendentes/,
    );
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id),
        plans = hoPlans();
      const ho = {
        id: "ho-guard",
        nome: "Cenário PF",
        tipo: "Manual",
        fluxo: ["Simulação"],
        etapaAlvo: "Simulação",
        etapas: { Simulação: "OK" },
      };
      for (const issue of c.issueIds)
        plans[issue] = {
          cenarios: [ho],
          aceite: { por: "PM", quando: "2026-10-07" },
        };
      saveTestData(hoPlansKey, plans);
      c.cenarios = [productionFromHO(c.issueIds[0], ho)];
      const bool = checklistItems().find((i) => i.tipo === "bool");
      c.checklist[bool.id] = "Não";
      persist();
      openQuickAction(c, "aprovar");
    }, id);
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id);
      delete c.checklist[checklistItems().find((i) => i.obrigatorio).id];
      openQuickAction(c, "aprovar");
    }, id);
    assert.equal(
      await page.locator("#quickActionBody .primary").isDisabled(),
      true,
    );
    await page.locator("#quickActionBody input[type=text]").fill("Gerente");
    await page.locator(".ack-incomplete input").check();
    await page
      .locator("[name=exceptionReason]")
      .fill("Exceção de checklist controlada");
    assert.equal(
      await page.locator("#quickActionBody .primary").isEnabled(),
      true,
    );
    await page.locator(".ack-incomplete input").uncheck();
    assert.equal(
      await page.locator("#quickActionBody .primary").isDisabled(),
      true,
    );
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id);
      c.checklist = seedChecklistAnswers("full");
      openQuickAction(c, "aprovar");
    }, id);
    assert.doesNotMatch(
      await page.textContent(".approval-readiness"),
      /atenção/,
    );
    assert.equal(await page.locator(".ack-incomplete").count(), 0);
    await page.locator("#quickActionBody input").first().fill("Gerente");
    await page.locator("#quickActionBody .primary").click();
    assert.equal(
      await page.evaluate((id) => changes.find((c) => c.id === id).status, id),
      "Aprovada",
    );
    await page.evaluate(
      (id) => openChecklist(changes.find((c) => c.id === id)),
      id,
    );
    assert.equal(await page.locator(".ck-row.nao").count(), 0);
    assert.equal(
      await page
        .locator(".ck-opt.nao.sel")
        .first()
        .evaluate((e) => getComputedStyle(e).backgroundColor),
      "rgb(11, 125, 40)",
    );
    assert.equal(
      await page.locator("#checklistBar").getAttribute("class"),
      "progress-fill ok",
    );
    await page.click("#closeChecklist");
    // Texto simples preserva aprovação; mudança de janela exige nova aprovação.
    await page.evaluate(
      (id) => openCompose({ editing: changes.find((c) => c.id === id) }),
      id,
    );
    await page
      .locator("#changeForm [name=observacao]")
      .fill("Apenas correção textual");
    await page.locator("#changeForm button[type=submit]").click();
    assert.equal(
      await page.evaluate((id) => changes.find((c) => c.id === id).status, id),
      "Aprovada",
    );
    await page.evaluate(
      (id) => openCompose({ editing: changes.find((c) => c.id === id) }),
      id,
    );
    await page.locator("#changeForm [name=dataProducao]").fill("2027-01-10");
    await page.locator("#changeForm button[type=submit]").click();
    assert.equal(
      await page.evaluate((id) => changes.find((c) => c.id === id).status, id),
      "Em aprovação",
    );
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id);
      aprovar(c, { por: "Gerente" });
      const plans = hoPlans();
      plans[c.issueIds[0]].aceite.quando = "2026-10-08";
      saveTestData(hoPlansKey, plans);
      openQuickAction(c, "confirmarSubida");
    }, id);
    await page.locator("#quickActionBody input").first().fill("TL");
    await page.locator("#quickActionBody .primary").click();
    assert.equal(
      await page.evaluate((id) => changes.find((c) => c.id === id).status, id),
      "Em aprovação",
    );
    console.log("PASS revisão HO e janela");
    // Encerrada: nenhuma mutação por editar, reprogramar, checklist ou plano.
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id);
      c.status = "Executada";
      c.aceiteProducao = { por: "PO" };
      c.encerramento = { por: "TL" };
      persist();
      showDetail(c);
    }, id);
    assert.match(await page.textContent("#detailActions"), /apenas|consulta/);
    assert.equal(await page.locator("#detailActions button").count(), 0);
    const before = await page.evaluate(
      (id) => JSON.stringify(changes.find((c) => c.id === id)),
      id,
    );
    await page.evaluate((id) => {
      const c = changes.find((c) => c.id === id);
      openCompose({ editing: c });
      reprogramar(c, { novaData: "2028-01-01" });
      removeChange(c);
      openScenarios(c);
    }, id);
    assert.equal(await page.locator("#changeDialog").isVisible(), false);
    assert.equal(await page.locator("#saveScenario").isVisible(), false);
    assert.equal(await page.locator("#scenarioList select").count(), 0);
    assert.equal(
      await page.evaluate(
        (id) => JSON.stringify(changes.find((c) => c.id === id)),
        id,
      ),
      before,
    );
    await page.keyboard.press("Escape");
    await page.evaluate(
      (id) => openChecklist(changes.find((c) => c.id === id)),
      id,
    );
    assert.equal(await page.locator("#saveChecklist").isVisible(), false);
    assert.equal(
      await page.locator("#checklistBody button:enabled").count(),
      0,
    );
    assert.deepEqual(errors, []);
    console.log(
      "PASS pré-requisitos, checklist respondido independentemente da opção, edição textual/janela, HO alterada, GMUD encerrada protegida.",
    );
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
