const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const assert = require("node:assert/strict"),
  fs = require("node:fs"),
  path = require("node:path");
(async () => {
  const browser = await chromium.launch({
    headless: true,
    ...(process.env.CHROME_PATH
      ? { executablePath: process.env.CHROME_PATH }
      : {}),
  });
  try {
    const context = await browser.newContext({
        viewport: { width: 1440, height: 1000 },
      }),
      p = await context.newPage(),
      base = process.env.ISSUEFLOW_URL || "http://localhost:8080",
      errors = [],
      report = [];
    p.setDefaultTimeout(8000);
    p.on("pageerror", (e) => errors.push(e.message));
    const fill = async (form, name, value) =>
      p.locator(`${form} [name=${name}]`).fill(value);
    await p.goto(base + "/testes.html");
    await p.click("#newCase");
    await fill("#caseForm", "nome", "DEMO E2E · PF Hipoteca · Smoke");
    await p.locator("#caseForm [name=tipo]").selectOption("Manual");
    await p
      .locator("#caseForm [name=etapaAlvo]")
      .selectOption("Criação de Pedido");
    await fill("#caseForm", "cobertura", "Smoke E2E");
    await fill("#caseForm", "componentes", "api-demo-e2e");
    await p.click("#caseForm button[type=submit]");
    assert(!(await p.locator("#caseDialog").isVisible()));
    for (const [suffix, type] of [
      ["SUCESSO", "success"],
      ["REPLANEJADA", "replanned"],
      ["ROLLBACK", "rollback"],
      ["DEPLOY", "deployed"],
      ["PROD-VALIDADO", "validated"],
    ]) {
      console.log("Iniciando " + suffix);
      const issue = "DEMO-E2E-" + suffix,
        rdm = "DEMO-" + suffix;
      await p.goto(base + "/index.html");
      await p.click("#newIssue");
      for (const [name, value] of Object.entries({
        squad: "Validação do fluxo",
        idIssue: issue,
        descricao: "Exemplo ponta a ponta: " + suffix,
        servicos: "api-demo-e2e",
        dataInicialHomologacao: "2026-10-08",
        dataFinalHomologacao: "2026-10-09",
        dataProducao: "2026-10-14",
        dataAberturaChange: "2026-10-11",
      }))
        await fill("#form", name, value);
      await p.locator("#form [name=ambiente]").selectOption("homologacao");
      await p.click("#form button[type=submit]");
      assert(!(await p.locator("#dialog").isVisible()));
      await p.goto(base + "/homologacao.html?issue=" + issue);
      await p.click("#openPicker");
      await p.locator("#paneSuggested input[type=checkbox]").first().check();
      await p.click("#addSuggested");
      await p.locator(".ho-case summary").first().click();
      await p.locator(".ho-fill-ok").click();
      await p.click("#saveHO");
      await fill("#hoApprove", "por", "Produto Demo");
      await fill(
        "#hoApprove",
        "nota",
        "Homologação concluída para validação do fluxo " + suffix,
      );
      await p.click("#hoApprove button[type=submit]");
      assert.match(await p.textContent("#hoAcceptanceBadge"), /aprovada/);
      await p.goto(base + "/changes.html");
      await p.click("#newChange");
      await p.fill("#pickerSearch", issue);
      await p.locator("#issuePicker input[type=checkbox]").check();
      assert.equal(
        await p.locator("#changeForm [name=dataProducao]").inputValue(),
        "2026-10-14",
      );
      await fill("#changeForm", "rdm", rdm);
      await fill("#changeForm", "smeTl", "TL Demo");
      await fill("#changeForm", "po", "PO Demo");
      await fill("#changeForm", "dataProducao", "2026-10-09");
      await p.click("#changeForm button[type=submit]");
      assert.match(await p.textContent("#changeError"), /depois do fim/);
      await fill("#changeForm", "dataProducao", "2026-10-14");
      await p.click("#changeForm button[type=submit]");
      assert(!(await p.locator("#changeDialog").isVisible()));
      const id = await p.evaluate(
        (rdm) => changes.find((c) => c.rdm === rdm).id,
        rdm,
      );
      const row = () => p.locator("#agendaRows tr").filter({ hasText: rdm });
      await row()
        .getByRole("button", { name: "Aprovar subida", exact: true })
        .click();
      await fill("#quickActionBody", "por", "Gerente Demo");
      assert(await p.locator("#quickActionBody .primary").isDisabled());
      await p.click("#closeQuickAction");
      await row()
        .getByRole("button", { name: /Testes de PROD pendentes/ })
        .click();
      await p.click("#toggleHO");
      await p.locator("#scenarioHO input:not(:disabled)").check();
      await p.click("#addProductionSelection");
      await p.click("#saveScenario");
      console.log("Issue, HO e GMUD cadastradas: " + suffix);
      // Checklist com Não é resposta válida; deixar um obrigatório em branco para testar exceção.
      await row()
        .getByRole("button", { name: /Checklist/ })
        .click();
      const segments = p.locator(".ck-seg");
      for (let i = 0; i < (await segments.count()); i++)
        await segments
          .nth(i)
          .getByRole("button", { name: "Não", exact: true })
          .click();
      const fields = p.locator("#checklistBody input");
      for (let i = 0; i < (await fields.count()); i++)
        await fields
          .nth(i)
          .fill(
            (await fields.nth(i).getAttribute("type")) === "number"
              ? "1"
              : "Verificado no exemplo",
          );
      await p
        .locator(".ck-seg")
        .first()
        .getByRole("button", { name: "Não", exact: true })
        .click();
      await p.click("#saveChecklist");
      async function approve() {
        await row()
          .getByRole("button", { name: "Aprovar subida", exact: true })
          .click();
        await fill("#quickActionBody", "por", "Gerente Demo");
        assert(await p.locator("#quickActionBody .primary").isDisabled());
        await p.locator(".ack-incomplete input").check();
        assert(await p.locator("#quickActionBody .primary").isEnabled());
        await p.locator("#quickActionBody .primary").click();
        assert.equal(
          await p.evaluate((id) => changes.find((c) => c.id === id).status, id),
          "Aprovada",
        );
      }
      await approve();
      // Correção de texto não desfaz aprovação.
      await row()
        .getByRole("button", { name: "Editar GMUD", exact: true })
        .click();
      await fill(
        "#changeForm",
        "observacao",
        "Texto alterado após aprovação para testar preservação.",
      );
      await p.click("#changeForm button[type=submit]");
      assert.equal(
        await p.evaluate((id) => changes.find((c) => c.id === id).status, id),
        "Aprovada",
      );
      if (type === "replanned") {
        await row()
          .getByRole("button", { name: "Reprogramar subida", exact: true })
          .click();
        await fill("#quickActionBody", "novaData", "2026-10-09");
        await fill("#quickActionBody", "por", "TL Demo");
        await fill(
          "#quickActionBody",
          "nota",
          "Ajuste da janela para corrigir implantação.",
        );
        await p.locator("#quickActionBody .primary").click();
        assert.match(
          await p.textContent("#quickActionBody .action-form > .action-error"),
          /depois do fim/,
        );
        await fill("#quickActionBody", "novaData", "2026-10-16");
        await p.locator("#quickActionBody .primary").click();
        assert.equal(
          await p.evaluate((id) => changes.find((c) => c.id === id).status, id),
          "Em aprovação",
        );
        await approve();
        report.push({
          issue,
          rdm,
          id,
          result: "Replanejada, reaprovada e aguardando subida",
        });
        continue;
      }
      await row()
        .getByRole("button", { name: "✓ Subida realizada", exact: true })
        .click();
      await p.locator("#quickActionBody .primary").click();
      assert.equal(
        await p.evaluate((id) => changes.find((c) => c.id === id).status, id),
        "Executada",
      );
      await p.goto(base + "/producao.html?change=" + id);
      assert(await p.locator("#poFinish").isDisabled());
      await p.fill("#poPerson", "PO Demo");
      if (type === "deployed") {
        report.push({
          issue,
          rdm,
          id,
          result: "Deploy realizado; validação de PROD pendente",
        });
        continue;
      }
      if (type === "validated") {
        await p.locator(".po-all-ok").click();
        await p.click("#poFinish");
        report.push({
          issue,
          rdm,
          id,
          result: "PROD validado; encerramento pelo TL pendente",
        });
        continue;
      }
      if (type === "success") {
        await p.locator(".po-all-ok").click();
        await p.click("#poFinish");
        assert(await p.locator("#poSave").isDisabled());
        await p.goto(base + "/changes.html");
        await row()
          .getByRole("button", { name: "Encerrar GMUD", exact: true })
          .click();
        await p.locator("#quickActionBody .primary").click();
        assert.equal(
          await row()
            .getByRole("button", { name: "Editar GMUD", exact: true })
            .count(),
          0,
        );
        await row()
          .getByRole("button", { name: "Resumo e histórico", exact: true })
          .click();
        assert.equal(await p.locator("#detailActions button").count(), 0);
        await p.click("#closeDetail");
        report.push({
          issue,
          rdm,
          id,
          result: "Finalizada com sucesso e bloqueada para alterações",
        });
      } else {
        await p.locator("#poScenarios select").last().selectOption("Falhou");
        await p.click("#poSave");
        assert.match(await p.textContent("#poError"), /motivo/);
        await p
          .locator("#poScenarios textarea")
          .fill("Erro ao criar pedido em PROD. Reversão necessária.");
        await p.click("#poSave");
        await p.goto(base + "/changes.html");
        await row()
          .getByRole("button", { name: "Registrar rollback", exact: true })
          .click();
        await fill("#rollbackForm", "por", "TL Demo");
        await fill(
          "#rollbackForm",
          "motivo",
          "Versão anterior restaurada após erro na criação do pedido.",
        );
        await p.click("#rollbackForm button[type=submit]");
        assert.equal(
          await p.evaluate((id) => changes.find((c) => c.id === id).status, id),
          "Rollback realizado",
        );
        report.push({
          issue,
          rdm,
          id,
          result: "Rollback com cenário, etapa e motivo preservados",
        });
      }
    }
    await p.goto(base + "/timeline.html");
    for (const kind of ["success", "replanned", "rollback"])
      assert((await p.locator(".delivery-" + kind).count()) > 0);
    await p.screenshot({ path: "/tmp/e2e-timeline.png", fullPage: true });
    // Nova GMUD para a mesma issue após rollback, sem substituir a tentativa anterior.
    if (process.env.UPDATE_EXAMPLES !== "1") {
      const original = report.find((r) => r.rdm === "DEMO-ROLLBACK"),
        snapshot = await p.evaluate(
          (id) =>
            JSON.stringify(
              JSON.parse(localStorage.getItem("issueflow.changes.v1")).find(
                (c) => c.id === id,
              ),
            ),
          original.id,
        );
      await p.goto(base + "/changes.html");
      await p.click("#newChange");
      await p.fill("#pickerSearch", original.issue);
      await p.locator("#issuePicker input:not(:disabled)").check();
      await fill("#changeForm", "rdm", "E2E-NOVA-TENTATIVA");
      await fill("#changeForm", "smeTl", "TL Correção");
      await fill("#changeForm", "po", "PO Correção");
      await fill("#changeForm", "dataProducao", "2026-10-15");
      await fill(
        "#changeForm",
        "observacao",
        "Nova versão corrigida após rollback",
      );
      await p.click("#changeForm button[type=submit]");
      assert(!(await p.locator("#changeDialog").isVisible()));
      const retryId = await p.evaluate(
        () => changes.find((c) => c.rdm === "E2E-NOVA-TENTATIVA").id,
      );
      assert.notEqual(retryId, original.id);
      const retryRow = () =>
        p.locator("#agendaRows tr").filter({ hasText: "E2E-NOVA-TENTATIVA" });
      await retryRow()
        .getByRole("button", { name: /Testes de PROD pendentes/ })
        .click();
      await p.click("#toggleHO");
      await p.locator("#scenarioHO input:not(:disabled)").check();
      await p.click("#addProductionSelection");
      await p.click("#saveScenario");
      assert.equal(
        await p.evaluate(
          (id) => execStatus(changes.find((c) => c.id === id).cenarios[0]),
          retryId,
        ),
        "Pendente",
      );
      await retryRow()
        .getByRole("button", { name: "Aprovar subida", exact: true })
        .click();
      await fill("#quickActionBody", "por", "Gerente Correção");
      await p.locator(".ack-incomplete input").check();
      await p.locator("#quickActionBody .primary").click();
      await retryRow()
        .getByRole("button", { name: "✓ Subida realizada", exact: true })
        .click();
      await p.locator("#quickActionBody .primary").click();
      await p.goto(base + "/producao.html?change=" + retryId);
      await p.locator(".po-all-ok").click();
      await p.click("#poFinish");
      await p.goto(base + "/changes.html");
      await retryRow()
        .getByRole("button", { name: "Encerrar GMUD", exact: true })
        .click();
      await p.locator("#quickActionBody .primary").click();
      assert.equal(
        await p.evaluate(
          (id) => JSON.stringify(changes.find((c) => c.id === id)),
          original.id,
        ),
        snapshot,
      );
      assert(
        await p.evaluate(
          (id) => !!changes.find((c) => c.id === id).encerramento,
          retryId,
        ),
      );
      await p.goto(base + "/gmud-timeline.html");
      await p.fill("#gmudMonth", "2026-10");
      await p.locator("#gmudMonth").dispatchEvent("change");
      await p.fill("#gmudSearch", original.issue);
      assert.equal(await p.locator(".gmud-row").count(), 2);
      assert.match(await p.textContent("#gmudGrid"), /Rollback realizado/);
      assert.match(await p.textContent("#gmudGrid"), /Finalizada com sucesso/);
      console.log(
        "PASS nova GMUD da mesma issue após rollback, encerramento e histórico anterior preservado",
      );
    }
    assert.deepEqual(errors, []);
    const data = await p.evaluate(() => {
      const all = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        all[key] = JSON.parse(localStorage.getItem(key));
      }
      return all;
    });
    const stores = {
      "issueflow.records.v1": data["issueflow.records.v1"].filter((i) =>
        i.idIssue.startsWith("DEMO-E2E-"),
      ),
      "issueflow.changes.v1": data["issueflow.changes.v1"].filter((c) =>
        report.some((r) => r.id === c.id),
      ),
      "issueflow.scenariocatalog.v1": data[
        "issueflow.scenariocatalog.v1"
      ].filter((c) => c.nome.startsWith("DEMO E2E")),
      "issueflow.hoplans.v1": Object.fromEntries(
        Object.entries(data["issueflow.hoplans.v1"]).filter(([id]) =>
          id.startsWith("DEMO-E2E-"),
        ),
      ),
    };
    if (process.env.UPDATE_EXAMPLES === "1")
      fs.writeFileSync(
        path.join(__dirname, "..", "modules/demo/examples.json"),
        JSON.stringify({ report, stores }, null, 2),
      );
    console.log(JSON.stringify(report, null, 2));
    console.log(
      "PASS cadastro via telas, HO, aprovação bloqueada, plano, checklist, edição, replanejamento, deploy registrado, PO, encerramento, rollback e timeline",
    );
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
