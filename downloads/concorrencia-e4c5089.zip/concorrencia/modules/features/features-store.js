// A limpeza das issues desativa a recriação dos exemplos.
const issueDemoSeedsEnabled = (() => {
  if (typeof DeliveryModules !== "undefined" && !DeliveryModules.isEnabled("delivery")) return false;
  try { return localStorage.getItem("issueflow.demo.issueSeeds.v1") !== "false"; }
  catch { return true; }
})();
const initialIssues = [
  {
    squad: "Canais Digitais",
    idIssue: "ISS-1042",
    descricao: "Ajustar validação de transferência Pix",
    dataInicialHomologacao: "2026-09-14",
    dataFinalHomologacao: "2026-09-22",
    dataAberturaChange: "2026-09-22",
    dataProducao: "2026-09-25",
    ambiente: "homologacao",
    servicos: ["api-pix", "api-contas"],
  },
  {
    squad: "Cartões",
    idIssue: "ISS-1043",
    descricao: "Atualizar limite disponível na fatura",
    dataInicialHomologacao: "2026-09-21",
    dataFinalHomologacao: "2026-10-05",
    dataAberturaChange: "2026-10-05",
    dataProducao: "2026-10-08",
    ambiente: "homologacao 2",
    servicos: ["api-cartoes", "api-limites", "api-clientes"],
  },
  {
    squad: "Onboarding",
    idIssue: "ISS-1044",
    descricao: "Revisar fluxo de abertura de conta",
    dataInicialHomologacao: "2026-10-01",
    dataFinalHomologacao: "2026-10-08",
    dataAberturaChange: "2026-10-10",
    dataProducao: "2026-10-13",
    ambiente: "efemero",
    servicos: [
      "api-clientes",
      "api-contas",
      "api-identidade",
      "web-onboarding",
    ],
  },
  {
    squad: "Crédito",
    idIssue: "ISS-1045",
    descricao: "Corrigir cálculo de parcelas na simulação",
    dataInicialHomologacao: "2026-08-10",
    dataFinalHomologacao: "2026-08-18",
    dataAberturaChange: "2026-08-18",
    dataProducao: "2026-08-21",
    ambiente: "homologacao",
    servicos: ["api-credito"],
  },
  {
    squad: "Investimentos",
    idIssue: "ISS-1046",
    descricao: "Exibir rentabilidade consolidada da carteira",
    dataInicialHomologacao: "2026-10-05",
    dataFinalHomologacao: "2026-10-16",
    dataAberturaChange: "2026-10-18",
    dataProducao: "2026-10-21",
    ambiente: "homologacao 2",
    servicos: ["api-investimentos", "api-clientes"],
  },
  {
    squad: "Segurança",
    idIssue: "ISS-1047",
    descricao: "Melhorar confirmação de acesso por biometria",
    dataInicialHomologacao: "2026-09-25",
    dataFinalHomologacao: "2026-10-02",
    dataAberturaChange: "2026-10-04",
    dataProducao: "2026-10-07",
    ambiente: "efemero",
    servicos: ["api-identidade", "api-clientes", "api-biometria"],
  },
  {
    squad: "Canais Digitais",
    idIssue: "ISS-1048",
    descricao: "Incluir comprovante no histórico de pagamentos",
    dataInicialHomologacao: "2026-10-12",
    dataFinalHomologacao: "2026-10-20",
    dataAberturaChange: "2026-10-20",
    dataProducao: "2026-10-23",
    ambiente: "homologacao",
    servicos: ["api-pagamentos", "api-contas"],
  },
  {
    squad: "Cartões",
    idIssue: "ISS-1049",
    descricao: "Corrigir notificação de compra internacional",
    dataInicialHomologacao: "2026-09-01",
    dataFinalHomologacao: "2026-09-10",
    dataAberturaChange: "2026-09-12",
    dataProducao: "2026-09-15",
    ambiente: "homologacao 2",
    servicos: ["api-cartoes"],
  },
  {
    squad: "Canais Digitais",
    idIssue: "ISS-1050",
    descricao: "Ajustar layout da área Pix",
    dataInicialHomologacao: "2026-10-01",
    dataFinalHomologacao: "2026-10-08",
    dataAberturaChange: "2026-10-10",
    dataProducao: "2026-10-13",
    ambiente: "homologacao",
    servicos: ["web-pix"],
  },
  {
    squad: "Canais Digitais",
    idIssue: "ISS-1051",
    descricao: "Melhorar acessibilidade da área Pix",
    dataInicialHomologacao: "2026-10-05",
    dataFinalHomologacao: "2026-10-10",
    dataAberturaChange: "2026-10-11",
    dataProducao: "2026-10-14",
    ambiente: "homologacao",
    servicos: ["web-pix"],
  },
  {
    squad: "Cartões",
    idIssue: "ISS-1052",
    descricao: "Redesenhar resumo da fatura",
    dataInicialHomologacao: "2026-10-03",
    dataFinalHomologacao: "2026-10-09",
    dataAberturaChange: "2026-10-11",
    dataProducao: "2026-10-14",
    ambiente: "homologacao",
    servicos: ["web-cartoes"],
  },
  {
    squad: "Cartões",
    idIssue: "ISS-1053",
    descricao: "Atualizar tela de desbloqueio",
    dataInicialHomologacao: "2026-10-06",
    dataFinalHomologacao: "2026-10-12",
    dataAberturaChange: "2026-10-12",
    dataProducao: "2026-10-15",
    ambiente: "homologacao 2",
    servicos: ["web-cartoes"],
  },
  {
    squad: "Investimentos",
    idIssue: "ISS-1054",
    descricao: "Novo filtro da carteira",
    dataInicialHomologacao: "2026-10-10",
    dataFinalHomologacao: "2026-10-16",
    dataAberturaChange: "2026-10-18",
    dataProducao: "2026-10-21",
    ambiente: "homologacao",
    servicos: ["web-investimentos"],
  },
  {
    squad: "Onboarding",
    idIssue: "ISS-1055",
    descricao: "Ajustar mensagens de cadastro",
    dataInicialHomologacao: "2026-10-02",
    dataFinalHomologacao: "2026-10-07",
    dataAberturaChange: "2026-10-09",
    dataProducao: "2026-10-12",
    ambiente: "homologacao",
    servicos: ["web-onboarding"],
  },
  {
    squad: "Crédito",
    idIssue: "ISS-1056",
    descricao: "Atualizar simulador e taxas",
    dataInicialHomologacao: "2026-10-06",
    dataFinalHomologacao: "2026-10-15",
    dataAberturaChange: "2026-10-17",
    dataProducao: "2026-10-20",
    ambiente: "homologacao",
    servicos: ["web-credito", "api-credito"],
  },
  {
    squad: "Crédito",
    idIssue: "ISS-1057",
    descricao: "Revisar regras de aprovação",
    dataInicialHomologacao: "2026-10-09",
    dataFinalHomologacao: "2026-10-18",
    dataAberturaChange: "2026-10-18",
    dataProducao: "2026-10-21",
    ambiente: "homologacao 2",
    servicos: ["api-credito", "api-clientes", "api-contas"],
  },
  {
    squad: "Segurança",
    idIssue: "ISS-1058",
    descricao: "Revisar autenticação de clientes",
    dataInicialHomologacao: "2026-10-01",
    dataFinalHomologacao: "2026-10-07",
    dataAberturaChange: "2026-10-09",
    dataProducao: "2026-10-12",
    ambiente: "homologacao",
    servicos: ["api-identidade", "api-clientes"],
  },
  {
    squad: "Canais Digitais",
    idIssue: "ISS-1059",
    descricao: "Atualizar confirmação de pagamentos",
    dataInicialHomologacao: "2026-10-14",
    dataFinalHomologacao: "2026-10-22",
    dataAberturaChange: "2026-10-24",
    dataProducao: "2026-10-27",
    ambiente: "homologacao",
    servicos: [
      "web-pagamentos",
      "api-pagamentos",
      "api-contas",
      "api-clientes",
    ],
  },
  {
    squad: "Investimentos",
    idIssue: "ISS-1060",
    descricao: "Ajustar contraste dos gráficos",
    dataInicialHomologacao: "2026-11-02",
    dataFinalHomologacao: "2026-11-06",
    dataAberturaChange: "2026-11-08",
    dataProducao: "2026-11-11",
    ambiente: "homologacao 2",
    servicos: ["web-investimentos"],
  },
  {
    squad: "Cartões",
    idIssue: "ISS-1061",
    descricao: "Validar fatura em ambiente isolado",
    dataInicialHomologacao: "2026-10-06",
    dataFinalHomologacao: "2026-10-12",
    dataAberturaChange: "2026-10-12",
    dataProducao: "2026-10-15",
    ambiente: "efemero",
    servicos: ["web-cartoes", "api-cartoes"],
  },
];

const storageKey = "issueflow.records.v1";
let issues;
try {
  const saved = JSON.parse(localStorage.getItem(storageKey));
  const fields = Object.keys(initialIssues[0]).filter((k) => k !== "servicos");
  issues =
    Array.isArray(saved) &&
    saved.every((x) => x && fields.every((k) => typeof x[k] === "string"))
      ? saved.map((x) => ({
          ...x,
          servicos: Array.isArray(x.servicos)
            ? x.servicos
            : initialIssues.find((i) => i.idIssue === x.idIssue)?.servicos ||
              [],
        }))
      : issueDemoSeedsEnabled ? structuredClone(initialIssues) : [];
} catch {
  issues = issueDemoSeedsEnabled ? structuredClone(initialIssues) : [];
}
// Mantém cadastros locais e acrescenta novos exemplos sem duplicar IDs.
for (const example of issueDemoSeedsEnabled ? initialIssues : [])
  if (!issues.some((i) => i.idIssue === example.idIssue))
    issues.push(structuredClone(example));
// Migra somente datas originais dos exemplos; preserva alterações locais.
const previousExampleDates = {
  "ISS-1042": { dataAberturaChange: "2026-09-23", dataProducao: "2026-10-02" },
  "ISS-1043": { dataAberturaChange: "2026-10-06", dataProducao: "2026-10-09" },
  "ISS-1044": { dataAberturaChange: "2026-10-09", dataProducao: "2026-10-15" },
  "ISS-1045": { dataAberturaChange: "2026-08-19", dataProducao: "2026-08-25" },
  "ISS-1046": { dataAberturaChange: "2026-10-19", dataProducao: "2026-10-22" },
  "ISS-1047": { dataAberturaChange: "2026-10-05", dataProducao: "2026-10-08" },
  "ISS-1048": { dataAberturaChange: "2026-10-21", dataProducao: "2026-10-28" },
  "ISS-1049": { dataAberturaChange: "2026-09-11", dataProducao: "2026-09-16" },
  "ISS-1050": { dataAberturaChange: "2026-10-09", dataProducao: "2026-10-13" },
  "ISS-1051": { dataAberturaChange: "2026-10-11", dataProducao: "2026-10-15" },
  "ISS-1052": { dataAberturaChange: "2026-10-10", dataProducao: "2026-10-14" },
  "ISS-1053": { dataAberturaChange: "2026-10-13", dataProducao: "2026-10-17" },
  "ISS-1054": { dataAberturaChange: "2026-10-17", dataProducao: "2026-10-21" },
  "ISS-1055": { dataAberturaChange: "2026-10-08", dataProducao: "2026-10-12" },
  "ISS-1056": { dataAberturaChange: "2026-10-16", dataProducao: "2026-10-20" },
  "ISS-1057": { dataAberturaChange: "2026-10-19", dataProducao: "2026-10-23" },
  "ISS-1058": { dataAberturaChange: "2026-10-08", dataProducao: "2026-10-12" },
  "ISS-1059": { dataAberturaChange: "2026-10-23", dataProducao: "2026-10-27" },
  "ISS-1060": { dataAberturaChange: "2026-11-07", dataProducao: "2026-11-11" },
  "ISS-1061": { dataAberturaChange: "2026-10-13", dataProducao: "2026-10-17" },
};
const incorrectExampleDates = {
  "ISS-1042": { dataAberturaChange: "2026-09-14", dataProducao: "2026-09-17" },
  "ISS-1043": { dataAberturaChange: "2026-09-27", dataProducao: "2026-09-30" },
  "ISS-1044": { dataAberturaChange: "2026-10-02", dataProducao: "2026-10-05" },
  "ISS-1045": { dataAberturaChange: "2026-08-10", dataProducao: "2026-08-13" },
  "ISS-1046": { dataAberturaChange: "2026-10-10", dataProducao: "2026-10-13" },
  "ISS-1047": { dataAberturaChange: "2026-09-26", dataProducao: "2026-09-29" },
  "ISS-1048": { dataAberturaChange: "2026-10-12", dataProducao: "2026-10-15" },
  "ISS-1049": { dataAberturaChange: "2026-09-04", dataProducao: "2026-09-07" },
  "ISS-1050": { dataAberturaChange: "2026-10-02", dataProducao: "2026-10-05" },
  "ISS-1051": { dataAberturaChange: "2026-10-04", dataProducao: "2026-10-07" },
  "ISS-1052": { dataAberturaChange: "2026-10-03", dataProducao: "2026-10-06" },
  "ISS-1053": { dataAberturaChange: "2026-10-04", dataProducao: "2026-10-07" },
  "ISS-1054": { dataAberturaChange: "2026-10-10", dataProducao: "2026-10-13" },
  "ISS-1055": { dataAberturaChange: "2026-09-29", dataProducao: "2026-10-02" },
  "ISS-1056": { dataAberturaChange: "2026-10-09", dataProducao: "2026-10-12" },
  "ISS-1057": { dataAberturaChange: "2026-10-11", dataProducao: "2026-10-14" },
  "ISS-1058": { dataAberturaChange: "2026-09-29", dataProducao: "2026-10-02" },
  "ISS-1059": { dataAberturaChange: "2026-10-16", dataProducao: "2026-10-19" },
  "ISS-1060": { dataAberturaChange: "2026-10-31", dataProducao: "2026-11-03" },
  "ISS-1061": { dataAberturaChange: "2026-10-04", dataProducao: "2026-10-07" },
};
let datesMigrated = false;
for (const issue of issues) {
  const previous = [
      previousExampleDates[issue.idIssue],
      incorrectExampleDates[issue.idIssue],
    ].filter(Boolean),
    example = initialIssues.find((i) => i.idIssue === issue.idIssue);
  if (
    example &&
    previous.some(
      (d) =>
        issue.dataProducao === d.dataProducao &&
        issue.dataAberturaChange === d.dataAberturaChange,
    ) &&
    issue.dataFinalHomologacao === example.dataFinalHomologacao
  ) {
    issue.dataProducao = example.dataProducao;
    issue.dataAberturaChange = example.dataAberturaChange;
    datesMigrated = true;
  }
}
if (datesMigrated) {
  try {
    localStorage.setItem(storageKey, JSON.stringify(issues));
  } catch {}
}
function subtractDays(value, count, businessDays = false) {
  const day = new Date(value + "T12:00:00");
  if (Number.isNaN(day.getTime())) return "";
  let remaining = count;
  while (remaining > 0) {
    day.setDate(day.getDate() - 1);
    if (!businessDays || ![0, 6].includes(day.getDay())) remaining--;
  }
  return `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}`;
}
function addBusinessDays(value, count) {
  const day = new Date(value + "T12:00:00");
  if (Number.isNaN(day.getTime())) return "";
  let remaining = count;
  while (remaining > 0) {
    day.setDate(day.getDate() + 1);
    if (![0, 6].includes(day.getDay())) remaining--;
  }
  return `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(day.getDate()).padStart(2, "0")}`;
}
function componentType(service) {
  return /^(web-|frontend(?:-|$)|front-)/i.test(service.trim())
    ? "Frontend"
    : "Backend";
}
function sharedEnvironment(service, a, b) {
  if (a === "efemero" || b === "efemero") return a === b;
  return componentType(service) === "Backend" || a === b;
}
function suggestionFor(issue, records) {
  if (
    issue.servicos.length !== 1 ||
    componentType(issue.servicos[0]) !== "Frontend" ||
    issue.ambiente === "homologacao 2"
  )
    return null;
  const target = { ...issue, ambiente: "homologacao 2" };
  const blocked = conflictsFor(target, records);
  return {
    available: !blocked.length,
    message: blocked.length
      ? `Homologação 2 ocupado para este frontend no período (${blocked.map((c) => c.issue.idIssue).join(", ")}).`
      : "Sugestão: utilizar Homologação 2. Apenas frontend envolvido e disponível no período; o backend permanece compartilhado com Homologação.",
  };
}
function conflictsFor(issue, records) {
  return records
    .filter(
      (other) =>
        other.idIssue !== issue.idIssue &&
        issue.dataInicialHomologacao <= other.dataFinalHomologacao &&
        other.dataInicialHomologacao <= issue.dataFinalHomologacao,
    )
    .map((other) => ({
      issue: other,
      servicos: issue.servicos.filter(
        (service) =>
          sharedEnvironment(service, issue.ambiente, other.ambiente) &&
          other.servicos.some(
            (s) =>
              s.toLocaleLowerCase("pt-BR") ===
              service.toLocaleLowerCase("pt-BR"),
          ),
      ),
      inicio:
        issue.dataInicialHomologacao > other.dataInicialHomologacao
          ? issue.dataInicialHomologacao
          : other.dataInicialHomologacao,
      fim:
        issue.dataFinalHomologacao < other.dataFinalHomologacao
          ? issue.dataFinalHomologacao
          : other.dataFinalHomologacao,
    }))
    .filter((c) => c.servicos.length);
}
